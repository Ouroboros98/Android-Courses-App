package com.example.recyclerviewfirebase;

import android.os.Parcel;
import android.os.Parcelable;

public class Course implements Parcelable {

    String id;
    String CourseName;
    String CourseCode;
    String Description;

    public Course() {

    }

    public Course(String id, String courseName, String courseCode, String description) {
        this.id = id;
        CourseName = courseName;
        CourseCode = courseCode;
        Description = description;
    }

    protected Course(Parcel in) {
        id = in.readString();
        CourseName = in.readString();
        CourseCode = in.readString();
        Description = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(CourseName);
        dest.writeString(CourseCode);
        dest.writeString(Description);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Course> CREATOR = new Creator<Course>() {
        @Override
        public Course createFromParcel(Parcel in) {
            return new Course(in);
        }

        @Override
        public Course[] newArray(int size) {
            return new Course[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCourseName() {
        return CourseName;
    }

    public void setCourseName(String courseName) {
        CourseName = courseName;
    }

    public String getCourseCode() {
        return CourseCode;
    }

    public void setCourseCode(String courseCode) {
        CourseCode = courseCode;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }
}
