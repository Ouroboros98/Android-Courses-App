package com.example.recyclerviewfirebase;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HelperAdapter extends RecyclerView.Adapter<HelperAdapter.ViewHolderClass> {

    List<Course> courseList;

    interface OnCourseClickListener {
        void onCourseClicked(Course course);
    }

    OnCourseClickListener listener;

    public HelperAdapter(List<Course> courseList, OnCourseClickListener listener) {
        this.courseList = courseList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HelperAdapter.ViewHolderClass onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout,parent,false);
        ViewHolderClass viewHolderClass=new ViewHolderClass(view);

        return viewHolderClass;
    }

    @Override
    public void onBindViewHolder(@NonNull HelperAdapter.ViewHolderClass viewHolderClass, int position) {
        final Course course = courseList.get(position);
        viewHolderClass.CourseName.setText(course.getCourseName());
        viewHolderClass.CourseCode.setText(course.getCourseCode());

        viewHolderClass.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onCourseClicked(course);
            }
        });

    }

    @Override
    public int getItemCount() {
        return courseList.size();
    }

    public class ViewHolderClass extends RecyclerView.ViewHolder{
         TextView CourseName,CourseCode;

        public ViewHolderClass(@NonNull View itemView) {
            super(itemView);
            CourseName=itemView.findViewById(R.id.CourseName);
            CourseCode=itemView.findViewById(R.id.CourseCode);
        }
    }
}
