package com.example.recyclerviewfirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<Course> fetchData;
    RecyclerView recyclerView;
    HelperAdapter helperAdapter;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        fetchData=new ArrayList<>();
        helperAdapter=new HelperAdapter(fetchData, new HelperAdapter.OnCourseClickListener() {
            @Override
            public void onCourseClicked(Course course) {
                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                intent.putExtra("course", course);
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(helperAdapter);


        databaseReference= FirebaseDatabase.getInstance().getReference("recyclerview");

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                fetchData.clear();
                for (DataSnapshot child:dataSnapshot.getChildren())
                {
                    Course data;
                    data = child.getValue(Course.class);
                    data.id = child.getKey();
                    fetchData.add(data);
                }
                helperAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
